const express = require("express");
const path = require("path");

const app = express();

// Define the path to the public directory where your index.html and bundle.js are
const publicPath = path.join(__dirname, "public");

// Serve static files from the public folder
app.use(express.static(publicPath));

// Handle all GET requests and serve index.html (for React Router to work)
app.get('*', (req, res) => {
    res.sendFile(path.join(publicPath, "index.html"));
});

// Start the server
app.listen(3000, () => {
    console.log("Server is running at http://localhost:3000");
});