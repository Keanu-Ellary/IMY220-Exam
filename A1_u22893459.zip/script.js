var pets = [
  { name: "Polly", species: "bird", age: 1, adopted: false, adoptedDate: "", adoptionFee: 560 },
  { name: "Fluffy", species: "dog", age: 4, adopted: true, adoptedDate: "2023-03-27",adoptionFee: 890 },
  { name: "Daisy", species: "dog", age: 9, adopted: true, adoptedDate: "2021-01-05", adoptionFee: 780 },
  { name: "Coco", species: "rabbit", age: 3, adopted: true, adoptedDate: "2019-01-30", adoptionFee: 615 },
  { name: "Simba", species: "cat", age: 4, adopted: true, adoptedDate: "2019-09-30", adoptionFee: 995 },
  { name: "Oreo", species: "rabbit", age: 4, adopted: false, adoptedDate: "", adoptionFee: 605 },
  { name: "Bella", species: "cat", age: 6, adopted: false, adoptedDate: "", adoptionFee: 810 },
  { name: "Milo", species: "bird", age: 3, adopted: false, adoptedDate: "", adoptionFee: 740 },
  { name: "Buddy", species: "dog", age: 10, adopted: true, adoptedDate: "2021-02-01", adoptionFee: 735 },
  { name: "Pebbles", species: "bird", age: 4, adopted: false, adoptedDate: "", adoptionFee: 505 },
];

class PetHandler
{
  constructor(pets)
  {
    this.pets = pets;
  }

  findPetsInAgeRange(minAge, maxAge)
  {
    const range = this.pets.filter(p => p.age >= minAge && p.age <= maxAge);
    return range;
  };

  listAdopedPetsByDate()
  {
    const adoptedPets = this.pets.filter(p => p.adopted === true);
    return adoptedPets.sort((a,b) =>
    {
      const date1 = new Date(a.adoptedDate);
      const date2 = new Date(b.adoptedDate);

      return date2 - date1;
    });
  }

  listPets(...args)
  {
    var listOfPets;

    if(args.length === 0)
    {
      listOfPets = this.pets;
    }
    else
    {
      if (Array.isArray(args[0])) 
      {
        listOfPets = args[0];
      } 
      else 
      {
        listOfPets = args;
      }
    }

    function createPetItem(pet) {
      var infoOfPet = `${pet.name} | ${pet.species} | Age: ${pet.age}`;
      if (pet.adopted) {
        infoOfPet += " | Adopted!";
      }
      return infoOfPet;
    }

    return listOfPets.map(createPetItem).join('\n');
  }

  calculateUniqueAdoptionFee(...petNames)
  {
    const unique = this.pets.filter((foundPet, petIndex, petSelf) => 
      petNames.includes(foundPet.name) && 
      petIndex === petSelf.findIndex(p => p.name === foundPet.name)
    );

    return unique.reduce((accumulatedTotal, foundPet) => accumulatedTotal + foundPet.adoptionFee, 0);
  }
}

Array.prototype.findPetsInAgeRange = function(minAge, maxAge)
{
  const range = this.filter(p => p.age >= minAge && p.age <= maxAge);
  return range;
}

Array.prototype.lastIndexOfistAdopedPetsByDate = function()
{
    const adoptedPets = this.filter(p => p.adopted === true);
    return adoptedPets.sort((a,b) =>
    {
      const date1 = new Date(a.adoptedDate);
      const date2 = new Date(b.adoptedDate);

      return date2 - date1;
    });
}

Array.prototype.listPets = function()
{
  function createPetItem(pet) {
    var infoOfPet = `${pet.name} | ${pet.species} | Age: ${pet.age}`;
    if (pet.adopted) {
      infoOfPet += " | Adopted!";
    }
      return infoOfPet;
    }

  return this.map(createPetItem).join('\n');
}

Array.prototype.calculateUniqueAdoptionFee = function(...petNames)
{
  const unique = this.filter((foundPet, petIndex, petSelf) => 
    petNames.includes(foundPet.name) && 
    petIndex === petSelf.findIndex(p => p.name === foundPet.name)
  );

  return unique.reduce((accumulatedTotal, foundPet) => accumulatedTotal + foundPet.adoptionFee, 0);
}