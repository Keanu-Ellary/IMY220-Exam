import React from "react";

class EditPost extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			name: "",
			content: "",
			author: { name: "" },
			comments: [],
		};

		this.fetchPost = this.fetchPost.bind(this);
		this.change = this.change.bind(this);
		this.hanSubmit = this.hanSubmit.bind(this);
	}

	componentDidMount() {
		this.fetchPost();
	}

	fetchPost() {
		const { id } = this.props;

		fetch(`http://localhost:5000/post/${id}`)
			.then((res) => res.json())
			.then((data) => {
				this.setState({
					name: data.name,
					content: data.content,
					author: data.author,
					comments: data.comments,
				});
			})
			.catch((error) => console.error("Error in fetch:", error));
	}

	change(event) {
		const { name, value } = event.target;
		this.setState({ [name]: value });
	}

	hanSubmit(event) {
		event.preventDefault();
		const { id } = this.props;
		const { name, content, author, comments } = this.state;

		fetch(`http://localhost:5000/edit/${id}`, {
			method: "PATCH",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ name, content, author, comments }),
		})
			.then((res) => {
				if (res.ok) {
					this.props.history.push("/");
				} else {
					console.error("Error updating");
				}
			})
			.catch((error) => alert("Error in editing:", error));
	}

	render() {
		const { name, content, author } = this.state;

		return (
			<div className="max-w-2xl mx-auto p-4 bg-white rounded-lg shadow-md">
				<h2 className="text-2xl font-bold mb-4">Editing</h2>
				<form onSubmit={this.hanSubmit} className="space-y-4">
					<label className="block">
						<span className="text-gray-700">Post:</span>
						<input
							type="text"
							name="name"
							value={name}
							onChange={this.change}
							className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-300"
						/>
					</label>

					<label className="block">
						<span className="text-gray-700">Content:</span>
						<textarea
							name="content"
							value={content}
							onChange={this.change}
							className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-300"
						/>
					</label>

					<label className="block">
						<span className="text-gray-700">Author:</span>
						<input
							type="text"
							name="author"
							value={author.name}
							onChange={(e) =>
								this.setState({ author: { name: e.target.value } })
							}
							className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-300"
						/>
					</label>

					<button
						type="submit"
						className="w-full bg-blue-500 text-white font-semibold py-2 rounded-md hover:bg-blue-600 transition"
					>
						Save
					</button>
				</form>
			</div>
		);
	}
}

export default EditPost;
