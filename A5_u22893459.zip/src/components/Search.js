import React from "react";

class Search extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {
            searchItem : '',
        };

        this.searchHandle = this.searchHandle.bind(this);
        this.changeHandle = this.changeHandle.bind(this);
        this.previous = this.previous.bind(this);
        this.next = this.next.bind(this);
    }

    changeHandle(event)
    {
        this.setState({searchItem : event.target.value});
    }

    searchHandle()
    {
        if(this.state.searchItem.trim() === '')
        {
            alert('Search cannot be empty');
            return;
        }

        this.props.onSearch(this.state.searchItem);
    }

    previous()
    {
        this.props.onPrevious();
    }

    next()
    {
        this.props.onNext();
    }

    render()
    {
        return(
            <div className="p-4 mb-4 bg-white border rounded-lg shadow-md">
                <h2 className="text-2xl font-bold mb-2">Search</h2>
                <input
                    type="text"
                    value={this.state.searchItem}
                    onChange={this.changeHandle}
                    className="border rounded-lg p-2 w-full mb-2"
                />
                <button onClick={this.searchHandle} className="bg-blue-500 text-white p-2 rounded-lg mr-2">Search</button>
                <br />
                <br />
                <button onClick={this.previous} className="bg-gray-500 text-white p-2 rounded-lg mr-2">Previous</button>
                <button onClick={this.next} className="bg-gray-500 text-white p-2 rounded-lg">Next</button>
            </div>
        );
    }
}

export default Search;