const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const { MongoClient, ObjectId } = require("mongodb");
const cors = require("cors");

const base =
	"mongodb+srv://u22893459:l3ob0g0gURdykg67@imy220.jk4tw.mongodb.net/?retryWrites=true&w=majority&appName=IMY220";
    
const client = new MongoClient(base);

const databaseApp = express();
databaseApp.use(cors());
databaseApp.use(bodyParser.json());

databaseApp.get('/posts', async(req, res) => 
{
    try
    {
        await client.connect();
        console.log("Connected to MongoDB");

        const db = client.db("Assignment_6");
        const collection = db.collection("Posts");

        const posts = await collection.find({}).toArray();
        
        res.status(200).send(posts);
    }
    catch(error)
    {
        console.error("Error in fetching:", error);
        res.status(500).send({message : "Error found", error : error.message});
    }
    finally
    {
        await client.close();
    }
});

databaseApp.get('post/:id', async (req, res) => {
    const {id} = req.params;

    try
    {
        await client.connect();
        console.log("Connected to MongoDB");

        const db = client.db("Assignment_6");
        const collection = db.collection("Posts");

        const user = await collection.findOne({_id : new ObjectId(id)}).toArray();

        if(!user)
        {
            throw new Error("User not found");
        }
        console.log(user);
        res.status(200).send({user});
    }
    catch(error)
    {
        console.error("Error in fetch:", error);
        res.status(500).send({message : "Error in fetch", error : error.message});
    }
    finally
    {
        await client.close();
    }
})

databaseApp.delete('/delete/:id', async (req, res) => 
{
    const {id} = req.params;

    try
    {
        await client.connect();
        console.log("Connected to MongoDB");

        const db = client.db("Assignment_6");
        const collection = db.collection("Posts");

        const deletion = await collection.deleteOne({_id : new ObjectId(id)});

        if(deletion.deletedCount === 1)
        {
            res.status(200).send({message : `Post with ID ${id} was deleted`});
        }
        else
        {
            throw new Error(`Post with ID ${id} was not found`);
        }
    }
    catch(error)
    {
        console.error("Error found:", error);
        res.status(500).send({message : "Error is deleting", error : error.message});
    }
    finally
    {
        await client.close();
    }
});

databaseApp.patch('/edit/:id', async (req, res) => {
    const {id} = req.params;
    const {name, content, author, comments} = req.body;

    try
    {
        await client.connect();
        console.log("Connected to MongoDB");

        const db = client.db("Assignment_6");
        const collection = db.collection("Posts");

        let fieldsToUpdate = {};
        if(name)
            fieldsToUpdate.name = name;
        if(content)
            fieldsToUpdate.content = content;
        if(author)
            fieldsToUpdate.author = author;
        if(comments)
            fieldsToUpdate.comments = comments;

        if(Object.keys(fieldsToUpdate).length === 0)
        {
            throw new Error("No fields to edit");
        }

        const update = await collection.updateOne(
            {_id : new ObjectId(id)},
            {$set : fieldsToUpdate}
        );

        if(update.matchedCount === 1)
        {
            res.status(200).send({message : `Post with ID ${id} was edited`});
        }
        else
        {
            throw new Error(`Post with ID ${id} was not found`);
        }
    }
    catch(error)
    {
        console.error("Error found:", error);
        res.status(500).send({message : "Error in editing", error : error.message});
    }
    finally
    {
        await client.close();
    }
});

databaseApp.listen(5000, () => {
    console.log("Server is running at http://localhost:5000");
})