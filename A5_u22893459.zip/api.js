const base = "https://swapi.dev/api/people/";

export async function getCharater(id) 
{
    try
    {
        const response = await fetch(`${base}${id}/`);
        if(!response.ok)
        {
            throw new Error(`Character with ID ${id} has not been found`);
        }

        const foundCharacter = await response.json();
        return foundCharacter;
    }
    catch(error)
    {
        console.error('Error caught: ' + error.message);
        return {error : error.message};
    }
}

export async function getCharaterName(name) 
{
    try 
    {
        const response = await fetch(base);

        if(!response.ok)
        {
            throw new Error('Error fetching character by name');
        }

        const data = await response.json();
        const foundCharacters = data.results;

        const character = foundCharacters.find(ch => ch.name.toLowerCase().includes(name.toLowerCase()));
        if(!character)
        {
            throw new Error('Character not found');
        }

        return character;
    }
    catch (error) 
    {
        console.error('Error caught' + error.message);
        return {error : error.message};
    }
}