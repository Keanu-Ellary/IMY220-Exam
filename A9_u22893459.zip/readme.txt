1. .babelrc: Babel which renders the program is empty and/or missing the necessary code:
added the code:
{
  "presets": ["@babel/preset-env", "@babel/preset-react"]
}
this is needed because it can configure Babel to take modern JS and JSX syntax and compiles it into a format that can be understood by older browsers and environments

2. index.js. The rendering for the specific component is missing in the render for the root
added: 
root.render(<App />);
without this, the root of the main page wont render the specific component that is needed. without this, the page would be empty/only show things that is on the index.html

3. RecipeCard.js: missing the import for React from react. 
added:
import React from "react";
without this, we wont be able to use the React methods/abilities(JSX interpretation), such as creating the component and rendering and stuff.

4. 

5. App.js: missing the exporting for this component.
added:
export default App;
without this, another file that wants to import this class to use it or send props or utilize its functions

6. RecipePage.js: the return for the render is not within the render function. 
moved the return into the render(), now looks like this:
render() {
    return (
      <div>
        <h2>{this.props.title}</h2>
        <p>{this.props.description}</p>
        <p>Ingredients:</p>
        <ul>
          {this.props.ingredients.map((ingredient, index) => {
            return <li>{ingredient}</li>;
          })}
        </ul>
        <p>Instructions:</p>
        <ol>
          {this.props.instructions.map((instruction, index) => {
            return <li key={index}>{instruction}</li>;
          })}
        </ol>
      </div>
    );
}
this is needed inside the render such that is allows and lets the render function render the specific html and JSX code to be rendered.

7. RecipePage.js: the key for the <ul> is missing.
added:
return <li key={index}>{ingredient}</li>;
this is necessary because React needs to use it to uniquely identify each item in the list; and the list is generated dynamically, so it is needed here.

8. RecipePage.js: the export is missing for the component
added:
export default RecipePage;
same reason as 5.

9. server.js: the app.get readfile cannot access the correct file because the path is incorrect
changed the original to:
fs.readFile('./public/recipes.json', 'utf8', (err, data) => {})
without the correct file path, it will always have an error because the file does not exist in the root

10. server.js: the data that comes back from the fs.readFile is not being obtained/stored anywhere
added: 
res.json(JSON.parse(data));
without this, the data that comes from the readFile(if successful), cannot be sent back to the client for further processing/displaying. now, the client can process this data.

11. server.js: the incorrect import for express is used(spelling error, that's that me expresso)
changed it to:
const app = express();
with the previous incorrect import, the express app will not be created/rendered/processed. now the app can be used with express and can be served

12. App.js: inside the setCurrentRecipe function, the comparison of the id is incorrect.
changed : const recipe = this.state.recipes.find((recipe) => recipe.id = id);
to this : const recipe = this.state.recipes.find((recipe) => recipe.id === id);
this is an actual comparison between the recipe.id and id. using only one '=' means assignment where as '===' or '==' means comparison. this ensures that we are not setting the recipe.id to only one id, we are allowing there to be a switch between recipes

13. server.js: incorrect function for using the static express(supposed to be app.use)
changed -> app.get(express.static('public'));
to this -> app.use(express.static('public'));
we are not wanting to "get" the public directory, we want to "use" it. so, we use app.use because it will utilize the static files stored -> index.html. now the middlewear can use Express to serve the files(index.html) inside the public directory

14. App.js: in the constructor, we are not supposed to set the props, we set the state
changed -> 
this.props = {
  recipes: "[]",
  currentRecipe: null,
};
to this-> 
this.state = {
  recipes: "[]",
  currentRecipe: null,
};
props are sent in from the main page(client)/or whatever component it came from. so we cant really change/set it like how we do with the state as props are a readonly. we should be using the state to hold data that we want to process using the props

15: App.js: the setting of the recipes in the state is done incorrectly. we want an array so
changed -> recipes: "[]",
to this -> recipes: [],
in the first implementation, we are physically setting the recipes to 2 square brackets as a string, whereas with the second implementation, we are actually setting it to an empty array

16: App.js: incorrect use of the componentDidUpdate
changed -> componentDidUpdate() {}
to this -> componentDidMount() {}
we want componentDidMount because we want the component to first mount to then display. using componentDidUpdate implies that the component is waiting for an update before doing its functions. and we dont want that

17: RecipeCard.js: the button in the render cannot find the function that is defined
changed -> <button onClick={onClick}>View Recipe</button>
to this -> <button onClick={this.onClick}>View Recipe</button>
this is required since, the onClick event handler is trying to find a function onClick that does not exist on its own, but using the "this" keyword, the event handler will look within the component for the function

18. RecipeCard.js: the id that is sent into the setCurrentRecipe cannot access the id
changed -> this.props.setCurrentRecipe(props.id);
to this -> this.props.setCurrentRecipe(this.props.id);
this is required because are working with a class-based component. without the "this" keyword, the class based component wont be able to access its own props since each class-based component has its own props and state.

19. App.js: the import for the RecipePage is missing
added: import RecipePage from "./components/RecipePage";
without this, the App component cannot access the component functions and rendering from the RecipePage that make it able to show the recipe in depth. this gives an error because to the App component, its just some random component

20. App.js: sending the ingredients to the RecipePage is missing
added -> ingredients={this.state.currentRecipe.ingredients}
without this, in the RecipePage component, the ingredients are undefined and the map function will not work