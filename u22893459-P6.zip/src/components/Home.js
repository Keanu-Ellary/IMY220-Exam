import React from "react";
import { Link } from "react-router-dom";

class Home extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			users: [],
		};

		// Bind the fetchUsers method to the class instance
		this.fetchUsers = this.fetchUsers.bind(this);
	}

	componentDidMount() {
		this.fetchUsers();
	}

	fetchUsers() {
		fetch("https://jsonplaceholder.typicode.com/users")
			.then((res) => res.json())
			.then((data) => {
				this.setState({ users: data });
			})
			.catch((error) => console.error("Error fetching users:", error));
	}

	render() {
		const { users } = this.state;

		return (
			<div>
				<h2>Users List</h2>
				{users.map((user) => (
					<div key={user.id}>
						<p>Name: {user.name}</p>
						<p>Email: {user.email}</p>
						<p>ID: {user.id}</p>
						<Link to={`/posts/${user.id}`}>View Posts</Link>
					</div>
				))}
			</div>
		);
	}
}

export default Home;
