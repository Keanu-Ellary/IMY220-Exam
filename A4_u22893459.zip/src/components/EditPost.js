import React from "react";

class EditPost extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {
            title: props.title,
            description : props.description,
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(event)
    {
        this.setState({[event.target.name] : event.target.value});
    }

    handleSubmit(event)
    {
        event.preventDefault();
        this.props.onChangesSave(this.state.title, this.state.description);
    }

    render()
    {
        const {title, description} = this.state;

        return(
            <form onSubmit={this.handleSubmit}>
                <div>
                    <label>Post Title:</label>
                    <input 
                        type="text"
                        name="title"
                        value={title}
                        onChange={this.handleChange}
                    />
                </div>
                <div>
                    <label>Post Description:</label>
                    <input
                        type="text"
                        name="description"
                        value={description}
                        onChange={this.handleChange}
                    />
                </div>

                <button type="submit">Save</button>
            </form>
        );
    }
}

export default EditPost;