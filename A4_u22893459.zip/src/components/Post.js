import React from "react"
import EditPost from "./EditPost";

class Post extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {
            currentlyEditing : false,
            title : this.props.title,
            author: this.props.author,
            description: this.props.description,
        };

        this.editToggle = this.editToggle.bind(this);
        this.handleChangesSave = this.handleChangesSave.bind(this);
    }

    editToggle()
    {
        this.setState({currentlyEditing: !this.state.currentlyEditing});
    }

    handleChangesSave(title, description)
    {
        this.setState({title, description, currentlyEditing: false});
    }

    render()
    {
        const {title, author, description, currentlyEditing} = this.state;

        return(
            <div>
                <h3>{title}</h3>
                <p>{author}</p>
                <hr />
                <p>{description}</p>
                <button onClick={this.editToggle}>
                    {currentlyEditing? 'Edit Post' : 'Edit Post'}
                </button>

                {currentlyEditing && (
                    <EditPost
                        title={title}
                        description={description}
                        onChangesSave={this.handleChangesSave}
                    />
                )}
            </div>
        );
    }
}

export default Post