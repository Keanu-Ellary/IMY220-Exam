enum Priority
{
    Low = 1,
    Medium,
    High,
}

interface Task
{
    id : number;
    name : string;
    date : string;
    category : "work" | "home" | "hobby" | "other";
    priority : Priority;
    tags? : string[];
    completed : boolean;
}

class TaskManager
{
    private tasksArr : Task[];

    constructor(t: Task[] = [])
    {
        this.tasksArr = t;
    }

    getTasks() : Task[]
    {
        return this.tasksArr;
    }

    addTask(t : Task): void
    {
        this.tasksArr.push(t);
    }

    listTasks() : string[]
    {
        return this.tasksArr.map(t => {
            let priLabel: string;
            switch(t.priority)
            {
                case Priority.High:
                    priLabel = "High";
                    break;
                case Priority.Medium:
                    priLabel = "Medium";
                    break;
                case Priority.Low:
                    priLabel = "Low";
                    break;
                default:
                    priLabel = "Low";
                    break;
            }

            let tagsFromUser: string;
            if(t.tags)
            {
                tagsFromUser = t.tags.join(', ');
            }
            else
            {
                tagsFromUser = "No tags";
            }

            let completionStatus: string;
            if(t.completed)
            {
                completionStatus = "Yes";
            }
            else
            {
                completionStatus = "No";
            }

            return  `${t.id} | ${t.name} (${t.category})<br>
            Priority: ${priLabel}<br>
            Date: ${t.date}<br>
            Tags: ${tagsFromUser}<br>
            Completed: ${completionStatus}`;
        });
    }

    sortTasksbyPriority() : void
    {
        this.tasksArr.sort((first, second) => second.priority - first.priority);
    }

    findTask(input: number | string) : Task | undefined
    {
        if(typeof input === "number")
        {
            return this.tasksArr.find(t => t.id === input);
        }
        else if (typeof input === "string")
        {
            return this.tasksArr.find(t => t.name.toLowerCase().includes(input.toLowerCase()));
        }

        return undefined;
    }
}