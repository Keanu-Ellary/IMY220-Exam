import React from "react";
import { Link } from "react-router-dom";

class PostList extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {
            posts : [],
            currentlyEditing : null,
        };

        this.getAllPosts = this.getAllPosts.bind(this);
        this.deleteHandle = this.deleteHandle.bind(this);
        this.editHandle = this.editHandle.bind(this);
        this.inputChange = this.inputChange.bind(this);
        this.saveEdits = this.saveEdits.bind(this);
    }

    componentDidMount()
    {
        this.getAllPosts();
    }

    getAllPosts()
    {
        fetch("http://localhost:5000/posts")
            .then((res) => res.json())
            .then((data) => {
                this.setState({posts : data});
            })
            .catch((error) => console.error("Error in fetching:", error));
    }

    deleteHandle(id)
    {
        fetch(`http://localhost:5000/delete/${id}`, {method: "DELETE"})
            .then((res) => {
                if(res.ok)
                {
                    this.setState((prevstate) => ({
                        posts : prevstate.posts.filter((post) => post._id !== id),
                    }));
                }
                else
                {
                    console.error("Error deleting");
                }
            })
            .catch((error) => alert("Error found:", error));
    }

    editHandle(p)
    {
        this.setState({currentlyEditing : p});
    }

    inputChange(event)
    {
        const {name, value} = event.target;

        this.setState((prevstate) => ({
            currentlyEditing: {
                ...prevstate.currentlyEditing,
                [name] : value,
            }
        }));
    }

    saveEdits()
    {
        const {currentlyEditing} = this.state;
        const {_id, name, content} = currentlyEditing;

        fetch(`http://localhost:5000/edit/${_id}`, {
            method: "PATCH",
            headers : {"Content-type" : "application/json"},
            body : JSON.stringify({name, content}),
        })
            .then((res) => {
                if(res.ok)
                {
                    this.setState((prevstate) => ({
                        posts : prevstate.posts.map((post) => 
                            post._id === _id ? currentlyEditing : post
                        ),
                        currentlyEditing : null,
                    }));
                }
                else
                {
                    console.error("Error in updating");
                }
            })
            .catch((error) => console.error("Error in saving changes:", error));
    }

    render() 
    {
        const { posts, currentlyEditing } = this.state;

        return (
            <div className="max-w-2xl mx-auto p-4">
                <h2 className="text-2xl font-bold mb-4">List of Posts</h2>
                {posts.length === 0 ? (
                    <p className="text-gray-500">No posts available.</p>
                ) : (
                    posts.map((post) => (
                        <div key={post._id} className="border rounded-lg shadow-md p-4 mb-4 bg-white">
                            {currentlyEditing && currentlyEditing._id === post._id ? (
                                <div>
                                    <h4 className="text-xl font-semibold">Editing Post</h4>
                                    <label className="block">
                                        <span className="text-gray-700">Post Name:</span>
                                        <input
                                            type="text"
                                            name="name"
                                            value={currentlyEditing.name}
                                            onChange={this.inputChange}
                                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-300"
                                        />
                                    </label>
                                    <label className="block">
                                        <span className="text-gray-700">Content:</span>
                                        <textarea
                                            name="content"
                                            value={currentlyEditing.content}
                                            onChange={this.inputChange}
                                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-300"
                                        />
                                    </label>
                                    <button
                                        onClick={this.saveEdits}
                                        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition mt-2"
                                    >
                                        Save
                                    </button>
                                </div>
                            ) : (
                                <div>
                                    <h4 className="text-xl font-semibold">{post.name}</h4>
                                    <p className="text-gray-700">{post.content}</p>

                                    <div>
                                        <h5 className="font-semibold">Comments:</h5>
                                        <ul className="mt-2">
                                            {post.comments.map((comm, i) => (
                                                <li key={i} className="border rounded p-2 mb-2">
                                                    <strong>{comm.name}:</strong> {comm.comment}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>

                                    <div className="flex justify-between mt-4">
                                        <button
                                            onClick={() => this.editHandle(post)}
                                            className="text-blue-500 hover:underline"
                                        >
                                            Edit this post
                                        </button>
                                        <button
                                            onClick={() => this.deleteHandle(post._id)}
                                            className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition"
                                        >
                                            Delete post
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    ))
                )}
            </div>
        );
    }
}

export default PostList;