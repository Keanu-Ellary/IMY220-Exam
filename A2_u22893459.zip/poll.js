class Poll
{
    constructor(arrayOfVotes)
    {
        this.votes = arrayOfVotes;
    }

    vote(name)
    {
        const searchForCat = this.votes.find(c => c.name === name);

        if(searchForCat)
        {
            searchForCat.votes++;
        }
    }

    getVotes()
    {
        return this.votes;
    }
}

module.exports = Poll;