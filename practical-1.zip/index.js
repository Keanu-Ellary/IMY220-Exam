// Student details here
const app = require('express')();
const path = require('path')

app.get('/', (req, res) => {
    return res.sendFile(path.join(__dirname, 'html/index.html'));
})

app.get('/date', (req, res) => {
    return res.json({ date: new Date() });
})

app.get('/ping', (req, res) => {
    return res.json({ message: 'pong' });
})

app.listen(3000, () => {
    console.log('Server is running on port 3000');
})