import React from "react";

class Line extends React.Component
{
    constructor(props)
    {
        super(props);
        // this.state = {
        //     isValid : false,
        //     distance: 0.0,
        // }; not needed

        // this.getDistance = this.getDistance.bind(this); dont have to bind getter
    }

    get Distance()
    {
        const {p1, p2} = this.props;

        // for(let i = 0; i < p1.length; i++)
        // {
        //     distance += Math.sqrt(p1[i] - p2[i], 2);
        // 

        //here is the correct way without using a for loop
        const distance = Math.sqrt(
            p1.map((coord, i) => Math.pow(coord - p2[i], 2)).reduce((sum, diff) => sum + diff, 0)
        );

        return distance.toFixed(2);
    }

    render()
    {
        const {p1, p2} = this.props;

        if(!Array.isArray(this.props.p1) || !Array.isArray(this.props.p2) || this.props.p1 === "" || this.props.p2 === "")// access p1 and p2 using the props
        {
            return <div>Invalid Points Entered</div>
        }

        return(
            <div>
                <h2>Line:</h2>
                <p>Point 1: {p1.join(';')}</p>
                <p>Point 2: {p2.join(';')}</p>
                <p>Dimension: {p1.length}</p>
                <p>Euclidean Distance: {this.Distance}</p>
            </div>
        );
    }
}

export default Line;