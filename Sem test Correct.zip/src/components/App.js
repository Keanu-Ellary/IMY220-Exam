import React from "react";
import Line from "./Line";
import PointInput from "./PointInput";

class App extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {
            point1 : null,
            point2 : null,
        };

        this.handlePointsSubmit = this.handlePointsSubmit.bind(this);
    }

    handlePointsSubmit(point1, point2) 
    {
        this.setState({ point1, point2 });
    }

    render()
    {
        const {point1, point2} = this.state;

        return(
            <div>
                <h1>IMY 220 Semester Test 1</h1>
                <PointInput onPointsSubmit={this.handlePointsSubmit}/>
                {point1 && point2 && <Line p1={point1} p2={point2}/>}
            </div>
        );
    }
}

export default App;