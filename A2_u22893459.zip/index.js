document.addEventListener('DOMContentLoaded', function(){
    const form = document.getElementById('poll');

    if(form)
    {
        form.addEventListener('submit', function(e){
            e.preventDefault();

            const usersChoice = document.querySelector('input[name="catName"]:checked');

            if(usersChoice)
            {
                const nameOfCat = usersChoice.value;

                socket.emit('vote', nameOfCat);
            }
        });
    }
});

const socket = io();

socket.on('connect', () => {
    console.log(`I connected with ID: ${socket.id}`);
});

socket.on('current', (v) => {
    v.forEach(votes => {
        const l = document.querySelector(`label[for="${votes.name}"] span`);

        if(l)
        {
            l.textContent = votes.votes;
        }
    });

    const total = v.reduce((addition, voteMade) => addition + voteMade.votes, 0);
    document.getElementById('total-votes').textContent = total;
});

socket.on('vote', (nameOfCat) => {
    const liveFeed = document.getElementById('feed');
    const usersVote = document.createElement('p');
    usersVote.textContent = `User ${socket.id.substring(0, 4)} voted for ${nameOfCat} at ${getTimeOfVote()}`;
    liveFeed.appendChild(usersVote);
})

function getTimeOfVote()
{
    const date = new Date();
    const h = date.getHours();
    const m = date.getMinutes();
    const s = date.getSeconds();

    const time = `${h.toString()}:${m.toString()}:${s.toString()}`;

    return time;
}