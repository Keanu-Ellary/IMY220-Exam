import React from "react";

class PointInput extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            p1: "",
            p2: "",
        }

        this.enterHandle = this.enterHandle.bind(this);
        this.enterChange = this.enterChange.bind(this);
    }

    enterHandle(event) 
    {
        this.setState({ [event.target.name]: event.target.value });
    }

    enterChange(event) {
        event.preventDefault();

        const p1 = this.state.p1.split(";").map(Number);
        const p2 = this.state.p2.split(";").map(Number);

        if(p1.length !== p2.length || p1.some(isNaN) || p2.some(isNaN))
        {
            alert("Enter valid numbers");
            return;
        }

        this.props.onPointsSubmit(p1, p2);

        // this.setState({arrP1 : this.state.p1.split(';')});
        // this.setState({arrP2 : this.state.p2.split(';')}); could cause set state problems
    }

    render() {
        const { p1, p2 } = this.state;

        return (
            <div>
                <h2>Point Input</h2>
                <form onSubmit={this.enterChange}>
                    <div>
                        <label>Point 1:</label>
                        <input
                            type="text"
                            name="p1"
                            placeholder="Enter values separated by semi-colons"
                            value={p1}
                            onChange={this.enterHandle}
                        />
                    </div>
                    <div>
                        <label>Point 2:</label>
                        <input
                            type="text"
                            name="p2"
                            placeholder="Enter values separated by semi-colons"
                            value={p2}
                            onChange={this.enterHandle}
                        />
                    </div>

                    <button type="submit">Calculate</button>
                </form>
            </div>
        );
    }
}

export default PointInput;