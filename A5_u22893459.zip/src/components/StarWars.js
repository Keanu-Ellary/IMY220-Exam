import React from "react";
import Person from "./Person";
import Search from "./Search";
import {getCharater, getCharaterName} from "../../api"

class StarWars extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {
            person : null,
            currentId : 1,
            error : '',
        };

        this.searchHandle = this.searchHandle.bind(this);
        this.previous = this.previous.bind(this);
        this.next = this.next.bind(this);
    }

    componentDidMount()
    {
        this.fetchPerson(this.state.currentId);
    }

    async fetchPerson(id)
    {
        if(id <= 0)
        {
            this.setState({error : 'No more characters'});
            return;
        }

        try 
        {
            const foundChar = await getCharater(id);
            if(foundChar.error)
            {
                this.setState({error : foundChar.error, person : null});
            }
            else
            {
                this.setState({person : foundChar, error : ''});
            }
        } 
        catch (error) 
        {
            this.setState({error : 'Error caught', person : null});
        }
    }

    async searchHandle(searchVal)
    {
        try 
        {
            const foundChar = await getCharaterName(searchVal);
            if (foundChar.error) 
            {
                this.setState({error : foundChar.error, person : null});
            }
            else
            {
                this.setState({person : foundChar, error : ''});
            }
        } 
        catch (error) 
        {
            this.setState({error : `Error is searching for ${searchVal}`, person : null});
        }
    }

    previous()
    {
        this.setState((prevState) => {
            const newID = prevState.currentId - 1;
            if(newID <= 0)
            {
                this.setState({error : 'No Previous character found'});
                return null;
            }

            return {currentId : newID};
        }, () => this.fetchPerson(this.state.currentId));
    }

    next()
    {
        this.setState((prevState) => {
            const newID = prevState.currentId + 1;
            return {currentId : newID};
        }, () => this.fetchPerson(this.state.currentId));
    }

    render()
    {
        const {person, error} = this.state;

        return(
            <div className="p-4 bg-gray-200 min-h-screen">
                <Search
                    onSearch={this.searchHandle}
                    onPrevious={this.previous}
                    onNext={this.next}
                />
                {error && <p className="text-red-500 font-bold">{error}</p>}

                <Person
                    person={person}
                />
            </div>
        );
    }
}

export default StarWars;