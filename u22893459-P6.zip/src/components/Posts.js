import React from "react";
import Post from "./Post";
import { withRouter } from "react-router-dom";

class Posts extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            posts: [],
            error: '',
        };

        this.getAllPosts = this.getAllPosts.bind(this);
    }

    componentDidMount() {
        this.getAllPosts();
    }

    getAllPosts() {
        const { id } = this.props.match.params; // Access route params via match

        fetch(`https://jsonplaceholder.typicode.com/posts?userId=${id}`)
            .then((res) => res.json())
            .then((data) => {
                if (data.length > 0) {
                    this.setState({ posts: data, error: '' });
                } else {
                    this.setState({ error: 'No posts found for this user' });
                }
            })
            .catch(() => this.setState({ error: 'Error fetching posts' }));
    }

    render() {
        const { posts, error } = this.state;

        if (error) {
            return <p>{error}</p>;
        }

        return (
            <div>
                <h2>User {this.props.match.params.id}'s Posts</h2>
                {posts.map((post) => (
                    <Post
                        key={post.id}
                        title={post.title}
                        body={post.body}
                    />
                ))}
            </div>
        );
    }
}

export default withRouter(Posts);