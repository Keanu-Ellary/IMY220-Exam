import React from "react"
import EditPost from "./EditPost"

class Splitter extends React.Component
{
    render()
    {
        const id = this.props.location.pathname.split('/').pop();
        return <EditPost {...this.props} id={id}/>;
    }
}

export default Splitter;