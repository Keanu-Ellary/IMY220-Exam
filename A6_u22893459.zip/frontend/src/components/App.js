import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PostList from './PostList';

class App extends React.Component 
{
    render()
    {
        return(
            <Router>
                <div>
                    <Routes>
                        <Route exact path='/' element={<PostList />}/>
                    </Routes>
                </div>
            </Router>
        );
    }
}

export default App;