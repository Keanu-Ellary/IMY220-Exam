const express = require('express')
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const Poll = require('./poll');

app.use(express.static(__dirname));

const pollOfCats = new Poll([
    {name: 'pebble', votes: 0},
    {name: 'sunshine', votes: 0},
    {name: 'miso', votes: 0},
    {name: 'panko', votes: 0},
    {name: 'snowball', votes: 0}
]);

http.listen(3000, () => {
    console.log(`Listening on http://localhost:3000`)
});

app.get('/index.js', (req, res) => {
    res.setHeader('Content-Type', 'application/javascript');
    res.sendFile(__dirname + '/index.js');
});

io.on('connection', (socket) => {
    console.log(`A user connected with ID: ${socket.id}`);

    socket.emit('current', pollOfCats.getVotes());

    socket.on('vote', (nameOfCat) => {
        pollOfCats.vote(nameOfCat);
        io.emit('current', pollOfCats.getVotes());
        io.emit('vote', nameOfCat)
    });

    socket.on('disconnect', () => {
        console.log('A user disconnected');
    });
});