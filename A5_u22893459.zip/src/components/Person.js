import React from "react";

class Person extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            person: null,
            error: '',
        };
    }

    componentDidUpdate(prevPro)
    {
        if(this.props.person !== prevPro.person)
        {
            this.setState({person : this.props.person, error : ''});
        }
    }

    render() {
        const { person, error } = this.state;

        if (error) {
            return <p className="text-red-500 font-bold">{error}</p>;
        }

        if (!person) {
            return <p className="text-gray-500">Loading...</p>;
        }

        return (
            <div className="p-4 border rounded-lg shadow-lg bg-gray-100">
                <h2 className="text-2xl font-bold mb-2">Person</h2>
                <h3 className="text-xl font-semibold mb-2">{person.name}</h3>
                <p className="text-lg mb-1">Birth Year: {person.birth_year}</p>
                <p className="text-lg mb-1">Eye Color: {person.eye_color}</p>
                <p className="text-lg mb-1">Gender: {person.gender}</p>
                <p className="text-lg">
                    Homeworld: 
                    <a href={person.homeworld} target="_blank" rel="noopener noreferrer" className="text-blue-500 underline">
                        {person.homeworld}
                    </a>
                </p>
            </div>
        );
    }
}

export default Person;