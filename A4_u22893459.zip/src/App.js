import React from "react";
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import Home from './pages/Home'
import Posts from './pages/Posts'

class App extends React.Component
{
    render()
    {
        return(
            <Router>
                <div>
                    <Routes>
                        <Route path="/" element={<Home />}/>
                        <Route path="/posts" element={<Posts />}/>
                    </Routes>
                </div>
            </Router>
        );
    } 
}

export default App;